import { chromium } from '/opt/node-tools/node_modules/playwright-core/index.mjs';
import fs from 'fs';
const [,, mode, out, ...rest] = process.argv;           // stills OUTDIR t1 t2 ... | video OUTDIR start end fps scale
const scale = mode==='video' ? Number(rest[3]||2) : Number(process.env.SCALE||1);
const browser = await chromium.launch({ executablePath:'/usr/bin/google-chrome', args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--force-color-profile=srgb','--hide-scrollbars'] });
const page = await browser.newPage({ viewport:{width:1920,height:1080}, deviceScaleFactor:scale });
page.on('pageerror', e=>console.error('PAGEERR',e.message));
await page.goto('file://'+process.cwd()+'/index.html'); await page.waitForFunction(()=>window.ready);
await page.evaluate(()=>Promise.all([...document.images].map(i=>i.decode().catch(()=>{}))));
fs.mkdirSync(out,{recursive:true});
const shot = async (t,file)=>{ await page.evaluate(async t=>{renderAt(t);await Promise.all([...document.images].map(i=>i.decode().catch(()=>{})));}, t);
  await page.screenshot({path:file, type:'jpeg', quality: mode==='video'?93:85}); };
if (mode==='stills') { for (const t of rest.map(Number)) await shot(t, `${out}/t_${t.toFixed(2)}.jpg`); }
else { const [a,b,fps]=rest.map(Number); let i=Math.round(a*fps); const end=Math.round(b*fps);
  for(; i<end; i++){ await shot(i/fps, `${out}/f_${String(i).padStart(5,'0')}.jpg`); if(i%50==0) console.log('frame',i); } }
await browser.close();
